#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "helpers.h"
#include "builtins.h"

int main(int argc, char* argv[]){
    int shell = 1;
    char infile[256] = "";
    char outfile[256] = "";
    while(shell == 1){
        printf("TUShell$ ");
        char str[10000] = "";
        fgets(str, 10000, stdin);
        char *inp = strdup(str);
        char **Prearray = parse(inp, " \n");
        int size_arr = 0;
        int in = 0;
        int out = 0;
        int new = 0;
        while(Prearray[size_arr] != NULL){
            if(strcmp(Prearray[size_arr], "<") == 0){
                if(in == 1){
                    puts("Cannot redirect a file to a process twice\n");
                    exit(EXIT_FAILURE);
                }
                in = 1;
                strcpy(infile, Prearray[size_arr + 1]);
                new = new + 2;
            }if(strcmp(Prearray[size_arr], ">") == 0){
                if(out == 1){
                    puts("Cannot redirect a process to a file twice\n");
                    exit(EXIT_FAILURE);
                }
                out = 1;
                strcpy(outfile, Prearray[size_arr + 1]);
                new = new+2;
            }
            size_arr++;
        }
        char *array[size_arr - new];
        for(int i = 0; i < size_arr; i++){
            if(strcmp(Prearray[i], "<") == 0 || strcmp(Prearray[i], ">") == 0 || strcmp(Prearray[i], infile) == 0 || strcmp(Prearray[i], outfile) == 0){
                continue;
            }else{
                array[i] = strdup(Prearray[i]);
            }
        }
        size_arr = size_arr - new;
        if(strcmp(array[0],"exit") == 0){
            printf("Exiting Shell\n");
            shell = 0;
        }else if(strcmp(array[0], "help") == 0){
            help();
        }else if(strcmp(array[0], "pwd") == 0){
            pwd();
        }else if(strcmp(array[0], "cd") == 0){
            cd(array[0+1]);
        }else{
            int child = fork();
            if(child < 0){
                printf("Execution failed\n");
                exit(EXIT_FAILURE);
            }else if(child == 0){//Child
                if(in == 1){
                    int inFileID = open(infile,O_RDWR | O_CREAT, 0777);
                    if(inFileID == -1){
                        puts("file open failed");
                        exit(EXIT_FAILURE);
                    }
                    dup2(inFileID, 0);
                    close(inFileID);
                }
                if(out == 1){
                    int outFileID = open(outfile,O_RDWR | O_CREAT | O_TRUNC, 0777);
                    if(outFileID == -1){
                        puts("file open failed");
                        exit(EXIT_FAILURE);
                    }
                    dup2(outFileID, 1);
                    close(outFileID);
                }
                char inp[strlen(array[0])+1];
                strcpy(inp, array[0]);
                if(inp[0] == 47){
                    strcpy(inp, array[0]);
                }else if(inp[0] == 46){
                    char inp2[strlen(inp)-1];
                    strcpy(inp2, inp + 2);
                }else{
                    struct stat info;
                    char *path = getenv("PATH");
                    char **paths = parse(path, ":");
                    int size_path = 0;
                    while(paths[size_path] != NULL){
                        size_path++;
                    }
                    for(int i = 0; i < size_path; i++){
                        char newPath[256] = "";
                        strcat(newPath, paths[i]);
                        strcat(newPath, "/");
                        strcat(newPath, inp);
                        if(stat(newPath, &info) == 0){
                            strcpy(inp, newPath);
                            break;
                        }
                        if(i == size_path - 1){
                            printf("Not a valid program start\n");
                            exit(EXIT_FAILURE);
                        }
                    }
                }char **exe = parse(array[0], "/");
                    int size_exe = 0;
                    while(exe[size_exe] != NULL){
                        size_exe++;
                    }
                    char *input[size_arr+1];
                    strcpy(input[0], exe[size_exe-1]);
                    for(int i = 1; i < size_arr; i++){
                        input[i] = strdup(array[0 + i]);
                    }
                    input[size_arr] = NULL;
                    execv(inp, input);
            }else{
                wait(NULL);
            }
        }
    }
    exit(EXIT_SUCCESS);
}