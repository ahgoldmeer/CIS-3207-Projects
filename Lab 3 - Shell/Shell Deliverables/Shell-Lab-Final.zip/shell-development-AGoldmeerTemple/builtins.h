#ifndef builtins_h
#define builtins_h

void help();
void pwd();
void cd(char *path);
void waitBuiltin();

#endif /* builtins_h */