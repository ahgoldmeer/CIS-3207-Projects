#include <string.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <time.h>

typedef struct product{
    char id[100];
    int count;
}Prod;

typedef struct buffer{
    int size;
    int *prod;
    int count;
    int get;
    int put;
}Buff;

void put(Buff *buffer1, Buff *buffer2, Prod *ReadBuff);

int get(Buff *buffer1, Buff *buffer2, Prod *ReadBuff);

int main(){
    struct buffer prod1 = {.count = 0, .get = 0, .put = 0, .size = 20};
    prod1.prod = malloc(sizeof(int) * prod1.size);
    struct buffer prod2 = {.count = 0, .get = 0, .put = 0, .size = 25};
    prod2.prod = malloc(sizeof(int) * prod2.size);
    for(int i = 0; i < /*304*/50; i++){
        struct product ReadBuff;
        read(STDIN_FILENO, &ReadBuff, sizeof(struct product));
        put(&prod1, &prod2, &ReadBuff);
        int getVal = get(&prod1, &prod2, &ReadBuff);
        printf("Get value: %d\n\n", getVal);
        // printf("PROD1: [");
        // for(int i = 0; i<prod1.size; i++){
        //     printf("%d, ", prod1.prod[1]);
        // }
        // printf("]");
        // printf("Count %d: %d\n", i, ReadBuff.count);
        // printf("ID %d: %s\n", i, ReadBuff.id);
        // printf("--------------\n");
    }
}

void put(Buff *buffer1, Buff *buffer2, Prod *ReadBuff){
    if(strcmp(ReadBuff->id, "product_1") == 0){
        if(buffer1->count != buffer1->size){
            buffer1->prod[buffer1->put] = ReadBuff->count;
            buffer1->count++;
            buffer1->put = (buffer1->put + 1) % buffer1->size;
            printf("PUT: Prod1 Count: %d, Prod1 Get: %d, Prod1 Put: %d, Prod1 Size: %d\n", buffer1->count, buffer1->get, buffer1->put, buffer1->size);
        }    
    }else{
        if(buffer2->count != buffer2->size){
            buffer2->prod[buffer2->put] = ReadBuff->count;
            buffer2->count++;
            buffer2->put = (buffer2->put + 1) % buffer2->size;
            printf("PUT: Prod2 Count: %d, Prod2 Get: %d, Prod2 Put: %d, Prod2 Size: %d\n", buffer2->count, buffer2->get, buffer2->put, buffer2->size);
        }    
    }
}

int get(Buff *buffer1, Buff *buffer2, Prod *ReadBuff){
    int get = 0;
    if(strcmp(ReadBuff->id, "product_1") == 0){
        if(buffer1->count != 0){
            get = buffer1->prod[buffer1->get];
            buffer1->prod[buffer1->get] = 0;
            buffer1->count = buffer1->count - 1;
            buffer1->get = (buffer1->get + 1) % buffer1->size;
            printf("GET: Prod1 Count: %d, Prod1 Get: %d, Prod1 Put: %d, Prod1 Size: %d\n", buffer1->count, buffer1->get, buffer1->put, buffer1->size);
        }    
    }else{
        if(buffer2->count != 0){
            get = buffer2->prod[buffer2->get];
            buffer2->prod[buffer2->get] = 0;
            buffer2->count = buffer2->count - 1;
            buffer2->get = (buffer2->get + 1) % buffer2->size;
            printf("GET: Prod2 Count: %d, Prod2 Get: %d, Prod2 Put: %d, Prod2 Size: %d\n", buffer2->count, buffer2->get, buffer2->put, buffer2->size);
        }    
    }
    return get;
}