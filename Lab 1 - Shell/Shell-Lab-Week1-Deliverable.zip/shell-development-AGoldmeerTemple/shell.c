#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include "helpers.h"

char** parse(char* line, const char delim[]);

int main(int argc, char* argv[]){
    int shell = 1;
    while(shell == 1){
        printf("TUShell$ ");
        char str[10000] = "";
        fgets(str, 10000, stdin);
        char *inp = strdup(str);
        char **array = parse(inp, " \n");
        if(strcmp(array[0],"exit") == 0){
            printf("Exiting Shell\n");
            shell = 0;
        }else if(strcmp(array[0], "help") == 0){
            printf("Current Commands:\n");
            printf("exit: exits shell\n");
            printf("cd [path]: takes in a directory path, changes the working directory to that path\n");
            printf("pwd: prints the current working directory\n");
        }else if(strcmp(array[0], "pwd") == 0){
            char buf[256];
            printf("%s\n", getcwd(buf, sizeof(buf)));
        }else if(strcmp(array[0], "cd") == 0){
            if(array[1] != NULL){
                chdir(array[1]);
            }else{
                printf("No specified directory\n");
            }
        }else{
            printf("Unrecognized Instruction\n");
        }
    }
    exit(EXIT_SUCCESS);
}

char** parse(char* line, const char delim[]){

    char** array = (char**)malloc(sizeof(char*));
    *array=NULL;
    int n = 0;

    char* buf = strtok(line,delim);

    if (buf == NULL){
        free(array);
        array=NULL;
        return array;
    }

    while (buf != NULL){
        array = (char**)realloc(array,(n+2)*sizeof(char*));

        if(array==NULL){
            free(array);
            array=NULL;
            return array;
        }

        array[n]=buf;
        n++;
        array[n]=NULL;

        buf = strtok(NULL,delim);
    }

    return array;
}