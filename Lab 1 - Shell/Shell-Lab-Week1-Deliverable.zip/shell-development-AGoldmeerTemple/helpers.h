#ifndef helpers_h
#define helpers_h

char** parse(char* line, const char delim[]);

#endif /* helpers_h */