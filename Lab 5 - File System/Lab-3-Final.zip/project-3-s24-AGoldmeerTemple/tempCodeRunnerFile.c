truct filedescriptors{
//     int fds[32];
//     int open;
// }fd;