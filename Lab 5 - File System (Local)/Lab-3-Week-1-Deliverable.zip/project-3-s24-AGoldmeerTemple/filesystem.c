#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>
#include "disk.c"
#include "disk.h"

//Struct for boot - contains locations for the FAT and Root Directory as pointers
typedef struct boot{
    int logicspace;
    int fat1;
    int fat2;
}boot;

//Struct for FAT - contains location of files - start block number, and pointer of current block number
typedef struct FAT{
    int block[4096];
}FAT;

//32 Bytes - For any file
typedef struct file{
    char name[15];
    char attribute[1];
    char createTime[2];
    char createDate[2];
    char LastAccessTime[2];
    char lastModifiedTime[2];
    char lastModifiedDate[2];
    int16_t startCluster;
    int32_t fileSize;
}file;

//Array of structs, with a maximum of 64 files
typedef struct logicSpace{
    file root[64];
}logicSpace;

int make_fs(char *disk_name);

int mount_fs(char *disk_name);

int unmount_fs(char *disk_name);

boot BOOT = {
        // .fat1 = ceil(sizeof(boot) + sizeof(logicSpace) / BLOCK_SIZE),
        // .fat2 = ceil(sizeof(boot) + sizeof(logicSpace) + sizeof(FAT) / BLOCK_SIZE),
        // .logicspace = 1,
        .fat1 = 1,
        .fat2 = ceil(sizeof(boot) + sizeof(FAT) / BLOCK_SIZE),
        .logicspace = ceil(sizeof(boot) + 2*sizeof(FAT) / BLOCK_SIZE)
};
FAT fat1;
FAT fat2;
logicSpace logic;

int main(){
    if(make_fs("Hello") == -1){
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
}

int make_fs(char *disk_name){
    if(make_disk(disk_name) == -1){
        perror("Disk Creation Failure");
        return -1;
    }
    if(open_disk(disk_name) == -1){
        perror("Disk Opening Failure");
        return -1;
    }
    memset(&fat1, 0, sizeof(FAT));
    memset(&fat2, 0, sizeof(FAT));
    memset(&logic, 0, sizeof(logicSpace));
    if(block_write(0, (char *) &BOOT) == -1){//Write boot to disk
        perror("Disk Write Failure");
        return -1;
    }
    // FAT fat1 = {0};
    if(block_write(BOOT.fat1, (char *) &fat1) == -1){//Write fat1 to disk
        perror("Disk Write Failure");
        return -1;
    }
    // FAT fat2 = {0};
    if(block_write(BOOT.fat2, (char *) &fat2) == -1){//Write fat2 to disk
        perror("Disk Write Failure");
        return -1;
    }
    // logicSpace logic = {0};
    if(block_write(BOOT.logicspace, (char *) &logic) == -1){//Write logic space / root directory to disk
        perror("Disk Write Failure");
        return -1;
    }
    if(close_disk() == -1){
        perror("Disk Closing Failure");
        return -1;
    }
    return 0;
}

int mount_fs(char *disk_name){
    if(open_disk(disk_name) == -1){
        perror("Disk Open Failure");
        return -1;
    }
    if(block_read(0, (char *) &BOOT) == -1){
        perror("Disk Read Failure");
        return -1;
    }
    if(block_read(BOOT.fat1, (char *) &fat1) == -1){
        perror("Disk Read Failure");
        return -1;
    }
    if(block_read(BOOT.fat2, (char *) &fat2) == -1){
        perror("Disk Read Failure");
        return -1;
    }
    if(block_read(BOOT.logicspace, (char *) &logic) == -1){
        perror("Disk Read Failure");
        return -1;
    }
    return 0;
}

int unmount_fs(char *disk_name){
    if(block_write(0, (char *) &BOOT) == -1){//Write boot to disk
        perror("Disk Write Failure");
        return -1;
    }
    if(block_write(BOOT.fat1, (char *) &fat1) == -1){//Write fat1 to disk
        perror("Disk Write Failure");
        return -1;
    }
    if(block_write(BOOT.fat2, (char *) &fat2) == -1){//Write fat2 to disk
        perror("Disk Write Failure");
        return -1;
    }
    if(block_write(BOOT.logicspace, (char *) &logic) == -1){//Write logic space / root directory to disk
        perror("Disk Write Failure");
        return -1;
    }
    //Close open file descriptors - How?
    //Need to create struct for file descriptors at all
    if(close_disk() == -1){
        perror("Disk Closing Error");
        return -1;
    }
    return 0;
}